# ##############################################################################
# TEST SCRIPT BASE
# ##############################################################################
try:
	shutil.rmtree(oridir+"ProgramAB/bots/gaelaimltest/aimlif")
except: 
	pass
i01 = Runtime.createAndStart("i01","InMoov")
i01.startMouth()
i01.startEar()
ear = i01.ear
mouth = i01.mouth

chatBot=Runtime.createAndStart("chatBot", "ProgramAB")
htmlFilter=Runtime.createAndStart("htmlFilter", "HtmlFilter")
ear.setLanguage("fr-FR")
mouth.setLanguage("FR") # on parle francais !
mouth.setVoice("julie") # on choisis une voix ( voir la liste des voix sur http://www.acapela-group.com/?lang=fr
chatBot=Runtime.createAndStart("chatBot", "ProgramAB")

chatBot.addTextListener(htmlFilter) # On creer une liaison de Program AB vers html filter
htmlFilter.addListener("publishText", python.name, "talk") 
chatBot.startSession("ProgramAB","Defaut","gaelaimltest")


def talk(data):
	if data:
		if data!="":
			mouth.speak(unicode(data,'utf-8'))

def onText(text):
		chatBot.getResponse(text.replace("'", " "))

python.subscribe(ear.getName(),"publishText")



webgui = Runtime.create("WebGui","WebGui")
webgui.autoStartBrowser(False)
webgui.startService()
webgui.startBrowser("http://localhost:8888/#/service/i01.ear")
ear.startListening()